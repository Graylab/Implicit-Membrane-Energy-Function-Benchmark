#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Author: Sebastian Kelm
# Created: 25/06/2009
#





import os.path, re
from array import array

from prosci.common import *
from prosci.util.gaps import gappify, deGappify, length_ungapped, isGap



def entryIsMaster(entry):
  t = entry.getType()
  return t == "structure" or t == "sequence"



class Ali:
    class EntryGroup:
        def __init__(self, *args):
            self.entries = []
            if len(args)==1 and not isinstance(args[0], Ali.Entry):
              args = args[0]
            for e in args:
              self.add(e)
        
        def __iter__(self):
            return self.entries.__iter__()

        def __getitem__(self, i):
            if isinstance(i, int):
              return self.entries[i]
            
            if i.startswith("structure"):
              i = "structure"
            elif i.startswith("sequence"):
              i = "sequence"
            
            if self.entries[0].getType() == i:
              return self.entries[0]
            
            ix = binarySearch(self.entries, i, 1)
            if ix >= 0:
              return self.entries[ix]
            
            raise IndexError("Ali.EntryGroup.__getitem__() : Entry not found: %s" % (str(i)))
        
        def __delitem__(self, i):
            if isinstance(i, int) or isinstance(i, slice):
              del self.entries[i]
              return
            
            if i.startswith("structure"):
              i = "structure"
            elif i.startswith("sequence"):
              i = "sequence"
            
            if self.entries[0].getType() == i:
              del self.entries[0]
              return
            
            ix = binarySearch(self.entries, i, 1)
            if ix >= 0:
              del self.entries[ix]
              return
            
            raise IndexError("Ali.EntryGroup.__getitem__() : Entry not found: %s" % (str(i)))
        
        def __getslice__(self, start=None, end=None):
            return Ali.EntryGroup(self.entries[start:end])

        def __len__(self):
            return len(self.entries)
        
        def __str__(self):
            return "%s\n" % (join("\n", self.entries))
        
        def toFastaString(self):
            "String representation of the object, in FASTA format (master sequences only)."
            return self.getMasterEntry().toFastaString()
        
        def __repr__(self):
            return "Ali.EntryGroup(%s)" % (repr(self.entries))
       
        def __cmp__(self, other):
            return cmp(self.getCode(), other.getCode())

        def add(self, entry, replace=False):
            assert isinstance(entry, Ali.Entry)

            if len(self) == 0:
              self.entries.append(entry)
              return

            assert entry.getCode() == self.getCode()
            if entry.isMaster():
              if self.hasMasterEntry():
                if replace:
                  self.entries[0] = entry
                else:
                  raise ValueError("Duplicate entry in Ali.EntryGroup : %s" % (entry.desc))
              else:
                self.entries.insert(0, entry)
            else:
              i = binarySearch(self.entries, entry, 1)
              if i >= 0:
                if replace:
                  self.entries[i] = entry
                else:
                  raise ValueError("Duplicate entry in Ali.EntryGroup : %s" % (entry.desc))
              else:
                self.entries.insert( -(1+i), entry )

        def getCode(self):
            if not len(self):
              return None
            return self.entries[0].getCode()
        
        def hasMasterEntry(self):
            return len(self.entries) > 0 and entryIsMaster(self.entries[0])
        
        def getMasterEntry(self):
            assert self.hasMasterEntry()
            return self.entries[0]
        
        def getMasterType(self):
            return self.getMasterEntry().getType()
        
        def make_gaps_consistent(self):
            mainseq = self.getMasterEntry().get_seq()
            for i in xrange(1,len(self)):
              entry = self[i]
              seq = array('c', entry.seq)
              for i,c in enumerate(mainseq):
                if isGap(c):
                  seq[i] = '-'
                elif isGap(seq[i]):
                  seq[i] = '?'
              entry.seq = seq.tostring()
        
        def gappify(self, force=True):
            """gappify() : Gappify (align) entries within the same EntryGroup"""
            template = self.getMasterEntry().get_seq()
            
            
            if force:
              diff = True
            else:
              diff = False
              for i in xrange(1,len(self)):
                lcur = len(self[i].get_seq())
                if lcur != len(template):
                  if length_ungapped(template) != length_ungapped(self[i].get_seq()):
                    raise IllegalState("Ungapped lengths differ between master and slave entries in same EntryGroup!")
                  diff = True
                  break
            
            if diff:
              for i in xrange(1,len(self)):
                entry = self[i]
                newseq = gappify(template, deGappify(entry.seq))
                if not newseq:
                  raise ValueError("Gappification of entry group '%s' failed!" % (entry.code))
                entry.seq = newseq
        
        def align(self, other, degappify=False):
            """align(other, degappify=False) : Align this EntryGroup to another using a sequence alignment of the master entries.
            
            If degappify==True, will first remove all gaps from sequences before realigning.
            Calls gappify() on both EntryGroups after performing the alignment of the master sequences.
            """
            self.getMasterEntry().align(other.getMasterEntry(), degappify)
            self.gappify()
            other.gappify()
        
        def delete_types(self, typenames):
          entries = []
          for e in self:
            if e.isMaster() or (e not in typenames):
              entries.append(e)
          self.entries = entries
        
        def keep_types(self, typenames):
          entries = []
          for e in self:
            if e.isMaster() or (e in typenames):
              entries.append(e)
          self.entries = entries
    
    
    class Entry:
        def __init__(self, *args):
            if len(args) == 1:
              args = args[0]
            assert len(args) in (2,3)
            
            if len(args) == 2 or not args[2]:
              # FASTA format
              self.code = args[0]
              self.desc = "sequence"
              self.seq  = args[1]
            else:
              # PIR format ( .ali .tem )
              self.code, self.desc, self.seq = args
            
            if self.code and self.code[0] == '>':
              self.code = self.code[1:]
            if self.seq and self.seq[-1] == '*':
              self.seq = self.seq[:-1]
        
        # Make Entry object seem like a list
        #
        def __iter__(self):
            yield self.code
            yield self.desc
            yield self.seq
        
        def __getitem__(self, i):
            if   0==i:
                return self.code
            elif 1==i:
                return self.desc
            elif 2==i:
                return self.seq
            raise IndexError("list index out of range")
            
        def __len__(self):
            return 3
        
        def __str__(self):
            return ">%s\n%s\n%s*\n" % (self.code, self.desc, self.seq)
        
        def toFastaString(self):
            "String representation of the object, in FASTA format."
            return ">%s\n%s\n"%(self.code, self.seq)

        
        def __repr__(self):
            return "Ali.Entry(%s,%s,%s)" % (repr(self.code), repr(self.desc), repr(self.seq))
        
        def __cmp__(self, other):
            if isinstance(other, Ali.Entry):
              return cmp(self.desc, other.desc)
            else:
              return cmp(self.desc, str(other))

        def getCode(self):
            return self.code

        def getDesc(self):
            return self.desc
        
        def getStructureFilename(self, searchdirs=None):
            def resolve(fname):
              if searchdirs:
                for dir in searchdirs:
                  if os.path.exists("%s/%s"%(dir, fname)):
                    return os.path.abspath("%s/%s"%(dir, fname))
              if os.path.exists(fname):
                return os.path.abspath(fname)
              else:
                return None
            
            if not self.isMaster():
              raise ValueError("Entry is not a master entry (type 'structure' or 'sequence'). Actual type: %s"%(self.getType()))
            code = self.getCode()
            if code.startswith("P1;"):
              code=code[3:]
            codelist = [code]
            fields = self.getDesc().split(":")
            if len(fields)>1:
              codelist.append(fields[1])
            
            for code in codelist:
              for ext in ["pdb", "atm", "ent"]:
                fname = resolve("%s.%s"%(code, ext))
                if fname:
                  return fname
              
            fname = resolve("pdb%s.ent"%(code))
            if fname:
              return fname
            
            raise NotFoundError("Could not find structure file for entry with code '%s' in directories %s. Example filename: %s"%(self.getCode(), str(searchdirs), codelist[0]+".pdb"))

        def getType(self):
            if self.desc.startswith("structure"):
              return "structure"
            elif self.desc.startswith("sequence"):
              return "sequence"
            else:
              return self.desc
        
        def isMaster(self):
            t = self.getType()
            return t == "structure" or t == "sequence"
        
        def get_seq(self):
            return self.seq
        
        def align(self, other, degappify=False):
            """align(other, degappify=False) : Align this Entry to another using a sequence alignment.
            
            If degappify==True, will first remove all gaps from sequences before realigning.
            """
            from prosci.util.seq import align as seqalign
            assert self.getCode() != other.getCode()
            
            if degappify:
              self.seq = deGappify(self.seq)
              other.seq = deGappify(other.seq)
            
            aligned = Ali(seqalign(self.toFastaString()+other.toFastaString()), fasta_mode=True)
            assert len(aligned) == 2
            assert deGappify(aligned[self.getCode()].getMasterEntry().get_seq()) == deGappify(self.seq)
            assert deGappify(aligned[other.getCode()].getMasterEntry().get_seq()) == deGappify(other.seq)
            self.seq  = aligned[self.getCode()].getMasterEntry().get_seq()
            other.seq = aligned[other.getCode()].getMasterEntry().get_seq()



  # BEGINNING OF ALI CLASS FUNCTIONS

    def __init__(self, inputdata, parent=None, ignore_duplicates=False, fasta_mode=False):
        if not (inputdata or parent):
          raise ArgumentError("Need to provide input data to Ali()!")
        
        self.parent      = None # points to a parent Ali instance, if available
        self.entrygroups = []
        
        if parent != None and not isinstance(parent, Ali):
            raise ArgumentError("Parent must be an instance of the Ali class!")
        
        if inputdata:
          if isinstance(inputdata, Ali) or \
            ((isinstance(inputdata, list) or isinstance(inputdata, tuple)) and isinstance(inputdata[0], Ali.EntryGroup)):
              self.parent = parent
              if None != inputdata:
                  self.entrygroups = [Ali.EntryGroup([Ali.Entry(e) for e in eg]) for eg in inputdata]
          elif parent == None:
              self.parse_file(inputdata, ignore_duplicates, fasta_mode)
        
    
    # Make Ali object seem like a list
    #
    def __iter__(self):
        return self.entrygroups.__iter__()
    
    def __getitem__(self, i):
        if isinstance(i, int):
          return self.entrygroups[i]
        for e in self.entrygroups:
          if e.getCode() == i:
            return e
        raise IndexError("Ali.__getitem__() : Ali.EntryGroup not found: %s" % (str(i)))
        
    def __len__(self):
        return len(self.entrygroups)
    
    def __str__(self):
        return "%s\n" % (join("\n", self.entrygroups))
    
    def __repr__(self):
        return "Ali(%s, %s)" % (repr(self.entrygroups), repr(self.parent))
    
    def __cmp__(self, other):
        if type(other) == type(None):
          return 1;
        return cmp(self.entrygroups, other.entrygroups)
    
    #def add(self, entrygroups, merge_duplicates=True, replace_duplicates=False):
    def add(self, entrygroups, merge_duplicates=False, replace_duplicates=False):
        
        if isinstance(entrygroups, Ali.EntryGroup):
          entrygroups = [entrygroups]
        else:
          assert isinstance(entrygroups, Ali)
        
        for eg in entrygroups:
          assert eg.getCode() != None
          
          if not self.has_entry(eg.getCode()):
            self.entrygroups.append(eg)
          else:
            if not merge_duplicates:
              raise ValueError("Duplicate Ali.EntryGroup in Ali: %s" % (eg.getCode()))
            
            oldeg = self[eg.getCode()]
            oldMaster = oldeg.getMasterEntry().get_seq()
            newMaster = eg.getMasterEntry().get_seq()
            if oldMaster == newMaster:
              for e in eg:
                if not e.isMaster():
                  oldeg.add(e, replace=replace_duplicates)
            elif deGappify(oldMaster) == deGappify(newMaster):
              for e in eg:
                if not e.isMaster():
                  oldeg.add(e, replace=replace_duplicates)
              oldeg.gappify()
            else:
              raise ValueError("Master sequences not equal: %s\n%s\n%s\n" % (eg.getCode(), oldMaster, newMaster))
        
    
    def has_entry(self, code):
      try:
        self[code]
        return True
      except IndexError:
        return False
    
    
    def has_equivalent_entry(self, entry):
        assert isinstance(entry, Ali.Entry)
        for eg in self:
          if eg.getCode() == entry.getCode():
            for e in eg:
              if e.getType() == entry.getType() or (e.isMaster() and entry.isMaster()):
                return True
            break
        return False
    
    
    def add_entry(self, entry, ignore_duplicates=False, replace_duplicates=False):
        """add_entry(entry, ignore_duplicates=False) : Returns True if the entry was added, False otherwise"""
        assert isinstance(entry, Ali.Entry)
        for eg in self:
          if eg.getCode() == entry.getCode():
            try:
              eg.add(entry, replace=replace_duplicates)
            except ValueError:
              if ignore_duplicates:
                return False
              raise
            return True
        self.add(Ali.EntryGroup(entry))
        return True
    
    
    def parse_file(self, fileobject, ignore_duplicates=False, fasta_mode=False):
        if not fileobject:
            return
        
        doClose = False
        
        if isinstance(fileobject, str):
          fileobject = fileobject.split("\n")
          if len(fileobject) == 1:
            fileobject = file(fileobject[0])
            doClose = True
        
        title = ''
        desc  = ''
        seq   = ''
        
        isAli   = False
        isFasta = False
        
        try:
          
          for line in fileobject:
              line = line.strip()
              if not line or line.startswith('*'):
                  continue
              elif line.startswith('>'):
                  if len(line) == 1:
                    raise ParsingError("ERROR: Stray '>' in sequence file!")
                  if title:
                      if seq:
                        isAli = True
                        if isFasta:
                          raise ParsingError("Sequence file must not mix ALI and FASTA formats:\n"+str(fileobject))
                      else:
                        isFasta = True
                        if isAli:
                          raise ParsingError("Sequence file must not mix ALI and FASTA formats:\n"+str(fileobject))
                      self.add_entry(Ali.Entry(title, desc, seq), ignore_duplicates)
                  title = line
                  desc = ''
                  seq = ''
              elif not desc:
                  desc = line
              elif fasta_mode:
                if desc.startswith("sequence") or desc.startswith("structure"):
                  desc = ""
                desc += line
              else:
                  seq += line
          
          if title and desc:
              if seq:
                isAli = True
                if isFasta:
                  raise ParsingError("Sequence file must not mix ALI and FASTA formats:\n"+str(fileobject))
              else:
                isFasta = True
                if isAli:
                  raise ParsingError("Sequence file must not mix ALI and FASTA formats:\n"+str(fileobject))
              self.add_entry(Ali.Entry(title, desc, seq), ignore_duplicates)
        
        finally:
          if doClose:
            fileobject.close()
    
    
    def gappify(self):
      """gappify() : Gappify (align) entries within the same EntryGroup"""
      for eg in self:
        eg.gappify()
    
    
    def keep_columns(self, selection):
        """keep_columns(selection) : remove all columns not in the selection.
        
        accepts a list of booleans or a list of integer indeces.
        Assumes that all EntryGroups are aligned to each other."""
        
        if not isinstance(selection[0], bool):
          numsel = selection
          selection = [False] * len(self[0][0].seq)
          for i in numsel:
            selection[i] = True
        
        for eg in self:
          for e in eg:
            assert len(selection) == len(e.seq)
            newseq = array('c')
            for i,c in enumerate(e.seq):
              if selection[i]:
                newseq.append(c)
            e.seq = newseq.tostring()
        
              
        
    
    def remove_gaps(self, template_seq=None):
        """remove_gaps([template_seq]) : Removes all alignment columns containing gaps.
        
        Only applicable if sequences are aligned (at least within each EntryGroup).
        If template_seq is given, all entries must be aligned to template_seq.
        """
        # Note that using this function will unalign entries with different codes!
        
        if template_seq:
          assert isinstance(template_seq[0], str)
        
        for eg in self:
            code = eg.getCode()
            
            if template_seq:
                template = template_seq
            else:
                if not eg.hasMasterEntry():
                  continue
                template = eg[0].seq
            
            seqs = []
            for entry in eg:
                assert len(entry.seq) == len(template)
                seqs.append(array('c', entry.seq))
            
            iend = len(template)
            ingap  = False
            for i in xrange(len(template), 0, -1):
                c = template[i-1]
                #print i,c,ingap
                if ingap:
                    if not isGap(c):
                        ingap = False
                        for seq in seqs:
                            del seq[i:iend]
                else:
                    if isGap(c):
                        ingap = True
                        iend  = i
            if ingap:
                #print "removing final gap"
                for seq in seqs:
                    del seq[:iend]
            
            for i,entry in enumerate(eg):
                entry.seq = seqs[i].tostring()
    
    
    def rename_entries(self, fromname, toname):
        
        if fromname[0] == ">":
          fromname = fromname[1:]
        if toname[0] == ">":
          toname = toname[1:]
        
        renamed = 0
        
        eg = self[fromname]

        for entry in eg:
          entry.code = toname
        
        return len(eg)
    
    
    def get_entries_by_type(self, etype):
        output = []
        for eg in self:
          try:
            output.append(eg[etype])
          except IndexError:
            pass
        return output

    
    def find_entry(self, code, etype):
        if code[0] == '>':
          code = code[1:]
        return self[code][etype]
    

    def find_entry_struc(self, code):
        return self.find_entry(code, "structure")
    
    
    def write_to_file(self, outfile, format="%s\n%s\n%s*"):
        """
        Write the entire Ali object to a specified file.
        
        write_to_file(outfile, format="%s\n%s\n%s*")
        
        Outfile can be a filename or a file object.
        The specified format is applied to each entry.
        """
        
        f = None
        doclose = True
        try:
          outfile.mode
          f = outfile
          doclose = False
        except AttributeError:
          f = open(outfile, 'w')
          doclose = True

        
        for entry in self:
          f.write(format % tuple(entry))
          f.write("\n")
        
        if doclose:
          f.close()
    
    
    def toFastaString(self):
        "String representation of the Ali object, in FASTA format."
        a=[]
        for eg in self:
          a.append(eg.toFastaString())
        return "".join(a)


    def align(self, degappify=False):
        """align(degappify=False) : Align all EntryGroups in a multiple sequence alignment, using the master entries.
        
        If degappify==True, will first remove all gaps from sequences before realigning.
        Calls gappify() on all EntryGroups after performing the alignment.
        """
        from prosci.util.seq import align as seqalign
        
        if degappify:
          for eg in self:
            eg.remove_gaps()
        
        aligned = Ali(seqalign(self.toFastaString()), fasta_mode=True)
        
        for eg_self, eg_aligned in zip(self, aligned):
          assert deGappify(eg_aligned.getMasterEntry().get_seq()) == deGappify(eg_self.getMasterEntry().get_seq())
          eg_self.getMasterEntry().seq  = eg_aligned.getMasterEntry().get_seq()
          eg_self.gappify()
    
    
    def unalign(self):
        """unalign() : Remove all gaps from all sequences.
        """
        for eg in self:
          e = eg.getMasterEntry()
          e.seq = deGappify(e.seq)
          eg.gappify()


    def delete_types(self, typenames):
      for eg in self:
        eg.delete_types(typenames)
    
    def keep_types(self, typenames):
      for eg in self:
        eg.keep_types(typenames)
